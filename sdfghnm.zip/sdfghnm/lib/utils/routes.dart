class MyRoutes {
  static String LoginRoutes = "/Login";
  static String HomeRoutes = "/Home";
  static String SignupRoutes = "/Signup";
  static String WellcomeRoutes = "/Wellcome";
  static String QrCodeRoutes = "/QrCode";
  static String ForgotPasswordPageRoutes = "/ForgotPasswordPage";

}
