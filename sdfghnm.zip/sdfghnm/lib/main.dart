import 'package:flutter/material.dart';
import 'package:untitled/firebase_options.dart';
import 'package:untitled/pages/signup/login.dart';
import 'package:untitled/pages/signup/signup.dart';
import 'package:untitled/pages/wellcome/wellcome.dart';
import 'package:untitled/utils/routes.dart';
// ignore: depend_on_referenced_packages
import 'package:firebase_core/firebase_core.dart' show Firebase;
import 'pages/home/home.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      themeMode: ThemeMode.dark,
      theme: ThemeData(
        primarySwatch: Colors.lightBlue,
      ),
      darkTheme: ThemeData(
        brightness: Brightness.light,
      ),
      debugShowCheckedModeBanner: false,
      // initialRoute: MyRoutes.HomeRoutes,
      routes: {
        "/": (context) => const Login(),
        MyRoutes.HomeRoutes: (context) => const Home(),
        MyRoutes.LoginRoutes: (context) => const Login(),
        MyRoutes.SignupRoutes: (context) => const Signup(),
        MyRoutes.WellcomeRoutes: (context) => const Wellcome()
      },
    );
  }
}
